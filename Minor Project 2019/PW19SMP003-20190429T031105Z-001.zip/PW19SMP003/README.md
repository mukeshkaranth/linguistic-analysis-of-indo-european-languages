Project ID:    PW19SMP003

Project Title: Linguistic Analysis of Indo-European Languages

Team Members:  Roshan U[01FB15ECS246], Sanath Bhimsen[01FB15ECS260], Mukesh M Karanth[01FB15ECS361].

Project Guide: Prof. Shreekanth M Prabhu

Abstract:-
	To analyse the closeness of Indo-European Languages to one another by means of Social Network Analysis 
	and then performing apropriate visualisation to depict our findings.